function [  ] = draw_data_figures(datas, years, options)
%DRAW_DATA_FIGURES Summary of this function goes here
%   Detailed explanation goes here

% options : struct
%     titles : vector
%     mode   : string : h -- hold on; f -- multipul figures; s -- sub figures
%     subplot_size : len 2 vector. subplot size. if mode is 's'

data_len = size(datas);
year_cnt = data_len(2);
sample_cnt = data_len(1);

if nargin < 3
    options = struct();
end
if isfield(options, 'titles')
    titles = options.titles;
else
    if isfield(options, 'title')
        thetitle = options.title;
    else
        thetitle = 'Figure';
    end
    titles = cell(sample_cnt, 1);
    for i = 1:sample_cnt
        titles{i} = sprintf('%s %d', thetitle, i);
    end
end
if isfield(options, 'mode')
    mode = options.mode;
else
    mode = 'h';
end
if isfield(options, 'subplot_size')
    subplot_size = options.subplot_size;
else
    subplot_size = [sample_cnt, 1];
end

for i = 1:sample_cnt
    if mode == 'm'
        figure(i);
    elseif mode == 's'
        subplot(subplot_size(1), subplot_size(2), i);
    end
    plot(years, datas(i,:));
    if mode == 'm' | mode == 's'
        title(titles{i});
    end
    if mode == 'h'
        hold on;
    end
end

end

