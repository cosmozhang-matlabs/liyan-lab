function [ rawdata, years, names ] = data_table_handle(raw_table_data)

size_data = size(raw_cell_data);

end