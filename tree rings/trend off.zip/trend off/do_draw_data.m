years = hs_20_years;
datas = hs_20_rawdata;

data_size = size(datas);
sample_cnt = data_size(1);

titles = cell(sample_cnt, 1);
for i = 1:sample_cnt
    titles{i} = sprintf('HS%02d', i);
end

options = struct();
options.mode = 's';
options.subplot_size = [5,4];
options.titles = titles;

draw_data_figures(hs_20_rawdata, hs_20_years, options);