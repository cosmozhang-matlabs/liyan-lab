function [ outdata ] = tr_detrend_gtp_exp( data, years )
% use exponential function to polyfit the grow trends


end